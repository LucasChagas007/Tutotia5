package br.ifs.tdd.model;

import java.time.LocalDate;

import br.ifs.tdd.exception.ValidacaoException;

public class Lote {
	private final Produto produto;
	private final int quantidade;
	private final LocalDate dataValidade;

	public Lote(Produto produto, int quantidade, LocalDate dataValidade) {
		if (produto == null)
			throw new ValidacaoException("Produto inválido");
		if (quantidade <= 0)
			throw new ValidacaoException("Quantidade inválida (deve ser positiva)");
		if (dataValidade == null)
			throw new ValidacaoException("Data de validade obrigatória");
		if (dataValidade.isBefore(LocalDate.now()))
			throw new ValidacaoException("Data de validade vencida");
		this.produto = produto;
		this.quantidade = quantidade;
		this.dataValidade = dataValidade;
	}

	public Produto getProduto() {
		return produto;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public LocalDate getDataValidade() {
		return dataValidade;
	}

	@Override
	public String toString() {
		return "Lote [produto=" + produto + ", quantidade=" + quantidade + ", dataValidade=" + dataValidade + "]";
	}
	
}
