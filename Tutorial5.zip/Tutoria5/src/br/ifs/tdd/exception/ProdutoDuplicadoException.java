package br.ifs.tdd.exception;

public class ProdutoDuplicadoException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ProdutoDuplicadoException(String mensagem) {
        super(mensagem);
    }
}
