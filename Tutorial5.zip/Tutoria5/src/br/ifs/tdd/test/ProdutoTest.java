package br.ifs.tdd.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import br.ifs.tdd.exception.ValidacaoException;
import br.ifs.tdd.model.Produto;

public class ProdutoTest{

	@Test @DisplayName("CT01: Construção de produto válido")
	void deveCriarProdutoValido() {
		Produto p = new Produto("1234567890123", "Caneta", "Esferográfica", 2.50);
		assertEquals("1234567890123", p.getIdentificador());
		assertEquals("Caneta", p.getNome());
		assertEquals("Esferográfica", p.getDescricao());
		assertEquals(2.50, p.getPreco());
	}

	@Test @DisplayName("CT02: Identificador vazio ou nulo")
	void identificadorVazioLancaValidacao() {
		ValidacaoException ex = assertThrows(ValidacaoException.class,
				() -> new Produto("", "Caneta", "Esferográfica", 2.50));
		assertEquals("Identificador obrigatório", ex.getMessage());
	}

	@Test @DisplayName("CT03: Identificador com caracteres não numéricos")
	void identificadorFormatoInvalido() {
		ValidacaoException ex = assertThrows(ValidacaoException.class,
				() -> new Produto("ABC123XYZ7890", "Caneta", "Esferográfica", 2.50));
		assertEquals("Formato do identificador inválido (apenas números)", ex.getMessage());
	}

	@Test @DisplayName("CT04: Identificador com comprimento diferente de 13")
	void identificadorTamanhoInvalido() {
		ValidacaoException ex = assertThrows(ValidacaoException.class,
				() -> new Produto("12345", "Caneta", "Esferográfica", 2.50));
		assertEquals("Tamanho do identificador inválido (13 caracteres)", ex.getMessage());
	}

	@Test @DisplayName("CT05: Nome vazio ou nulo")
	void nomeVazioLancaValidacao() {
		ValidacaoException ex = assertThrows(ValidacaoException.class,
				() -> new Produto("1234567890123", "", "Esferográfica", 2.50));
		assertEquals("Nome obrigatório", ex.getMessage());
	}

	@Test @DisplayName("CT06: Nome excede 100 caracteres")
	void nomeMuitoLongoLancaValidacao() {
		String nome = "A".repeat(101);
		ValidacaoException ex = assertThrows(ValidacaoException.class,
				() -> new Produto("1234567890123", nome, "Esferográfica", 2.50));
		assertEquals("Nome excede 100 caracteres", ex.getMessage());
	}

	@Test @DisplayName("CT07: Descrição vazia ou nula")
	void descricaoVaziaLancaValidacao() {
		ValidacaoException ex = assertThrows(ValidacaoException.class,
				() -> new Produto("1234567890123", "Caneta", "", 2.50));
		assertEquals("Descrição obrigatória", ex.getMessage());
	}

	@Test @DisplayName("CT08: Descrição excede 500 caracteres")
	void descricaoMuitoLongaLancaValidacao() {
		String desc = "D".repeat(501);
		ValidacaoException ex = assertThrows(ValidacaoException.class,
				() -> new Produto("1234567890123", "Caneta", desc, 2.50));
		assertEquals("Descrição excede 500 caracteres", ex.getMessage());
	}

	@Test @DisplayName("CT09: Preço inválido (zero ou negativo)")
	void precoInvalidoLancaValidacao() {
		ValidacaoException ex1 = assertThrows(ValidacaoException.class,
				() -> new Produto("1234567890123", "Caneta", "Esferográfica", 0));
		assertEquals("Preço inválido (deve ser positivo)", ex1.getMessage());

		ValidacaoException ex2 = assertThrows(ValidacaoException.class,
				() -> new Produto("1234567890123", "Caneta", "Esferográfica", -1.0));
		assertEquals("Preço inválido (deve ser positivo)", ex2.getMessage());
	}
}
