package br.ifs.tdd.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import br.ifs.tdd.exception.ValidacaoException;
import br.ifs.tdd.model.Lote;
import br.ifs.tdd.model.Produto;

public class LoteTest {

	@Test @DisplayName("CT10: Construção de lote válido")
	void deveCriarLoteValido() {
		Produto p = new Produto("1234567890123", "Caneta", "Esferográfica", 2.50);
		Lote l = new Lote(p, 20, LocalDate.now().plusDays(30));
		assertEquals(p, l.getProduto());
		assertEquals(20, l.getQuantidade());
		assertTrue(l.getDataValidade().isAfter(LocalDate.now()));
	}

	@Test @DisplayName("CT11: Produto nulo")
	void produtoNuloLancaValidacao() {
		ValidacaoException ex = assertThrows(ValidacaoException.class,
				() -> new Lote(null, 20, LocalDate.now().plusDays(30)));
		assertEquals("Produto inválido", ex.getMessage());
	}

	@Test @DisplayName("CT12: Quantidade inválida (zero ou negativa)")
	void quantidadeInvalidaLancaValidacao() {
		Produto p = new Produto("1234567890123", "Caneta", "Esferográfica", 2.50);
		ValidacaoException ex1 = assertThrows(ValidacaoException.class,
				() -> new Lote(p, 0, LocalDate.now().plusDays(30)));
		assertEquals("Quantidade inválida (deve ser positiva)", ex1.getMessage());

		ValidacaoException ex2 = assertThrows(ValidacaoException.class,
				() -> new Lote(p, -5, LocalDate.now().plusDays(30)));
		assertEquals("Quantidade inválida (deve ser positiva)", ex2.getMessage());
	}

	@Test @DisplayName("CT13: Data de validade nula")
	void validadeNulaLancaValidacao() {
		Produto p = new Produto("1234567890123", "Caneta", "Esferográfica", 2.50);
		ValidacaoException ex = assertThrows(ValidacaoException.class,
				() -> new Lote(p, 10, null));
		assertEquals("Data de validade obrigatória", ex.getMessage());
	}

	@Test @DisplayName("CT14: Data de validade vencida")
	void validadeVencidaLancaValidacao() {
		Produto p = new Produto("1234567890123", "Caneta", "Esferográfica", 2.50);
		LocalDate ontem = LocalDate.now().minusDays(1);
		ValidacaoException ex = assertThrows(ValidacaoException.class,
				() -> new Lote(p, 10, ontem));
		assertEquals("Data de validade vencida", ex.getMessage());
	}
}
