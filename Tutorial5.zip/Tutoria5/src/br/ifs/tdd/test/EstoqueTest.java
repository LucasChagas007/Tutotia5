package br.ifs.tdd.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import br.ifs.tdd.exception.EstoqueInsuficienteException;
import br.ifs.tdd.exception.OperacaoInvalidaException;
import br.ifs.tdd.exception.ProdutoDuplicadoException;
import br.ifs.tdd.exception.ProdutoNaoEncontradoException;
import br.ifs.tdd.exception.ValidacaoException;
import br.ifs.tdd.model.Produto;
import br.ifs.tdd.service.Estoque;

public class EstoqueTest {
    private Estoque estoque;
    private Produto produto;

    @BeforeEach
    void setUp() {
        estoque = new Estoque();
        produto = new Produto("1234567890123", "Caneta", "Esferográfica", 2.50);
    }

    // CT15: Cadastro de produto válido
    @Test @DisplayName("CT15: Cadastro de produto válido no estoque")
    void deveCadastrarProdutoValido() {
        estoque.cadastrar(produto);
        assertEquals(0, estoque.obterQuantidade(produto.getIdentificador()));
    }

    // CT16: Cadastro de produto nulo
    @Test @DisplayName("CT16: Cadastro de produto nulo")
    void cadastrarProdutoNuloLancaValidacao() {
    	ValidacaoException ex = assertThrows(ValidacaoException.class,
            () -> estoque.cadastrar(null));
        assertEquals("Produto inválido", ex.getMessage());
    }

    // CT17: Cadastro de produto duplicado
    @Test @DisplayName("CT17: Cadastro de produto duplicado")
    void cadastrarProdutoDuplicadoLancaExcecao() {
        estoque.cadastrar(produto);
        assertThrows(ProdutoDuplicadoException.class,
            () -> estoque.cadastrar(produto));
    }

    // CT18: Exclusão de produto válido no estoque sem lotes associados
    @Test @DisplayName("CT18: Remoção de produto sem lotes")
    void removerProdutoSemLotes() {
        estoque.cadastrar(produto);
        assertDoesNotThrow(() -> estoque.remover(produto.getIdentificador()));
    }

    // CT19: Exclusão de produto utilizando identificador nulo
    @Test @DisplayName("CT19: Remoção com identificador nulo")
    void removerNullLancaValidacao() {
        ValidacaoException ex = assertThrows(ValidacaoException.class,
            () -> estoque.remover(null));
        assertEquals("Identificador de produto inválido", ex.getMessage());
    }

    // CT20: Exclusão de produto não cadastrado
    @Test @DisplayName("CT20: Remoção de produto não cadastrado")
    void removerProdutoNaoCadastradoLancaExcecao() {
        assertThrows(ProdutoNaoEncontradoException.class,
            () -> estoque.remover(produto.getIdentificador()));
    }

    // CT21: Exclusão de produto cadastrado com lotes associados
    @Test @DisplayName("CT21: Remoção de produto com lotes associados")
    void removerProdutoComLotesLancaExcecao() {
        estoque.cadastrar(produto);
        estoque.adicionar(produto.getIdentificador(), 10, LocalDate.now().plusDays(5));
        OperacaoInvalidaException ex = assertThrows(OperacaoInvalidaException.class,
            () -> estoque.remover(produto.getIdentificador()));
        assertEquals("Remova os lotes associados primeiro", ex.getMessage());
    }

    // CT22: Busca de produto válido no estoque
    @Test @DisplayName("CT22: Busca de produto válido")
    void buscarProdutoValido() {
        estoque.cadastrar(produto);
        assertEquals(produto, estoque.buscar(produto.getIdentificador()));
    }

    // CT23: Busca de produto utilizando identificador nulo
    @Test @DisplayName("CT23: Busca com identificador nulo")
    void buscarNullLancaValidacao() {
        ValidacaoException ex = assertThrows(ValidacaoException.class,
            () -> estoque.buscar(null));
        assertEquals("Identificador de produto inválido", ex.getMessage());
    }

    // CT24: Busca de produto não cadastrado
    @Test @DisplayName("CT24: Busca de produto não cadastrado")
    void buscarProdutoNaoCadastradoLancaExcecao() {
        assertThrows(ProdutoNaoEncontradoException.class,
            () -> estoque.buscar(produto.getIdentificador()));
    }

    // CT25: Atualização de produto no estoque
    @Test @DisplayName("CT25: Atualização de produto válido")
    void atualizarProdutoValido() {
        estoque.cadastrar(produto);
        Produto atualizado = new Produto(produto.getIdentificador(), "Caneta Azul", "Esferográfica", 3.00);
        assertDoesNotThrow(() -> estoque.atualizar(atualizado));
        assertEquals("Caneta Azul", estoque.buscar(produto.getIdentificador()).getNome());
    }

    // CT26: Atualização de produto utilizando produto nulo
    @Test @DisplayName("CT26: Atualização com produto nulo")
    void atualizarNullLancaValidacao() {
        ValidacaoException ex = assertThrows(ValidacaoException.class,
            () -> estoque.atualizar(null));
        assertEquals("Produto inválido", ex.getMessage());
    }

    // CT27: Atualização de produto não cadastrado
    @Test @DisplayName("CT27: Atualização de produto não cadastrado")
    void atualizarProdutoNaoCadastradoLancaExcecao() {
        Produto outro = new Produto("9999999999999", "Caneta", "Esferográfica", 2.50);
        assertThrows(ProdutoNaoEncontradoException.class,
            () -> estoque.atualizar(outro));
    }

    // CT28: Adição de itens válidos no estoque
    @Test @DisplayName("CT28: Adição de itens válidos")
    void adicionarItensValidos() {
        estoque.cadastrar(produto);
        assertDoesNotThrow(() -> estoque.adicionar(produto.getIdentificador(), 30, LocalDate.now().plusDays(10)));
        assertEquals(30, estoque.obterQuantidade(produto.getIdentificador()));
    }

    // CT29: Adição de itens utilizando identificador nulo
    @Test @DisplayName("CT29: Adicionar com identificador nulo")
    void adicionarNullIdLancaValidacao() {
        ValidacaoException ex = assertThrows(ValidacaoException.class,
            () -> estoque.adicionar(null, 10, LocalDate.now().plusDays(5)));
        assertEquals("Identificador de produto inválido", ex.getMessage());
    }

    // CT30: Adição de itens utilizando identificador não cadastrado
    @Test @DisplayName("CT30: Adicionar produto não cadastrado")
    void adicionarProdutoNaoCadastradoLancaExcecao() {
        assertThrows(ProdutoNaoEncontradoException.class,
            () -> estoque.adicionar(produto.getIdentificador(), 10, LocalDate.now().plusDays(5)));
    }

    // CT31: Adição de itens utilizando quantidade negativa
    @Test @DisplayName("CT31: Adicionar com quantidade negativa")
    void adicionarQuantidadeNegativaLancaValidacao() {
        estoque.cadastrar(produto);
        ValidacaoException ex = assertThrows(ValidacaoException.class,
            () -> estoque.adicionar(produto.getIdentificador(), -5, LocalDate.now().plusDays(5)));
        assertEquals("Quantidade inválida", ex.getMessage());
    }

    // CT32: Adição de itens utilizando data de validade nula
    @Test @DisplayName("CT32: Adicionar com data de validade nula")
    void adicionarDataNullLancaValidacao() {
        estoque.cadastrar(produto);
        ValidacaoException ex = assertThrows(ValidacaoException.class,
            () -> estoque.adicionar(produto.getIdentificador(), 5, null));
        assertEquals("Data de validade inválida", ex.getMessage());
    }

    // CT33: Adição de itens utilizando data de validade vencida
    @Test @DisplayName("CT33: Adicionar com data de validade vencida")
    void adicionarDataVencidaLancaValidacao() {
        estoque.cadastrar(produto);
        ValidacaoException ex = assertThrows(ValidacaoException.class,
            () -> estoque.adicionar(produto.getIdentificador(), 5, LocalDate.now().minusDays(1)));
        assertEquals("Data de validade vencida", ex.getMessage());
    }

    // CT34: Retirada de itens válidos no estoque
    @Test @DisplayName("CT34: Retirar itens válidos")
    void retirarItensValidos() {
        estoque.cadastrar(produto);
        estoque.adicionar(produto.getIdentificador(), 15, LocalDate.now().plusDays(10));
        assertDoesNotThrow(() -> estoque.retirar(produto.getIdentificador(), 5));
        assertEquals(10, estoque.obterQuantidade(produto.getIdentificador()));
    }

    // CT35: Retirada priorizando lotes com validade mais próxima
    @Test @DisplayName("CT35: Retirar priorizando lotes")
    void retirarPriorizaLotes() {
        estoque.cadastrar(produto);
        estoque.adicionar(produto.getIdentificador(), 10, LocalDate.now().plusDays(5));
        estoque.adicionar(produto.getIdentificador(), 20, LocalDate.now().plusDays(30));
        estoque.retirar(produto.getIdentificador(), 15);
        // Lote mais próximo esgotado e restante deduzido do segundo lote
        assertEquals(15, estoque.obterQuantidade(produto.getIdentificador()));
    }

    // CT36: Retirada de itens utilizando identificador nulo
    @Test @DisplayName("CT36: Retirar com identificador nulo")
    void retirarNullIdLancaValidacao() {
        ValidacaoException ex = assertThrows(ValidacaoException.class,
            () -> estoque.retirar(null, 5));
        assertEquals("Identificador de produto inválido", ex.getMessage());
    }

    // CT37: Retirada de itens de produto não cadastrado
    @Test @DisplayName("CT37: Retirar produto não cadastrado")
    void retirarProdutoNaoCadastradoLancaExcecao() {
        assertThrows(ProdutoNaoEncontradoException.class,
            () -> estoque.retirar(produto.getIdentificador(), 5));
    }

    // CT38: Retirada de itens utilizando quantidade negativa
    @Test @DisplayName("CT38: Retirar quantidade negativa")
    void retirarQuantidadeNegativaLancaValidacao() {
        estoque.cadastrar(produto);
        ValidacaoException ex = assertThrows(ValidacaoException.class,
            () -> estoque.retirar(produto.getIdentificador(), -5));
        assertEquals("Quantidade inválida", ex.getMessage());
    }

    // CT39: Retirada de quantidade maior que a disponível
    @Test @DisplayName("CT39: Retirar quantidade maior que disponível")
    void retirarQuantidadeMaiorQueDisponivelLancaExcecao() {
        estoque.cadastrar(produto);
        estoque.adicionar(produto.getIdentificador(), 4, LocalDate.now().plusDays(10));
        assertThrows(EstoqueInsuficienteException.class,
            () -> estoque.retirar(produto.getIdentificador(), 5));
    }

    // CT40: Obtenção da quantidade total de itens no estoque
    @Test @DisplayName("CT40: Obter quantidade total no estoque")
    void obterQuantidadeTotal() {
        Produto outro = new Produto("0000000000001", "Lápis", "Grafite", 1.00);
        estoque.cadastrar(produto);
        estoque.cadastrar(outro);
        estoque.adicionar(produto.getIdentificador(), 15, LocalDate.now().plusDays(10));
        estoque.adicionar(outro.getIdentificador(), 5, LocalDate.now().plusDays(10));
        assertEquals(20, estoque.obterQuantidade());
    }

    // CT41: Obtenção da quantidade de um produto específico
    @Test @DisplayName("CT41: Obter quantidade de produto específico")
    void obterQuantidadeProdutoEspecifico() {
        estoque.cadastrar(produto);
        estoque.adicionar(produto.getIdentificador(), 15, LocalDate.now().plusDays(10));
        assertEquals(15, estoque.obterQuantidade(produto.getIdentificador()));
    }

    // CT42: Obtenção da quantidade de produto não cadastrado
    @Test @DisplayName("CT42: Obter quantidade de produto não cadastrado")
    void obterQuantidadeProdutoNaoCadastradoLancaExcecao() {
        assertThrows(ProdutoNaoEncontradoException.class,
            () -> estoque.obterQuantidade(produto.getIdentificador()));
    }

    // CT43: Obtenção da quantidade utilizando identificador nulo
    @Test @DisplayName("CT43: Obter quantidade com identificador nulo")
    void obterQuantidadeNullIdLancaValidacao() {
        ValidacaoException ex = assertThrows(ValidacaoException.class,
            () -> estoque.obterQuantidade(null));
        assertEquals("Identificador de produto inválido", ex.getMessage());
    }

    @Test @DisplayName("CT45: Gerar relatório CSV")
    void relatorioCsv() {
        estoque.cadastrar(produto);
        estoque.adicionar(produto.getIdentificador(), 2, LocalDate.now().plusDays(5));
        String csv = estoque.gerarRelatorioCSV();
        assertTrue(csv.startsWith("identificador,quantidade"));
        assertTrue(csv.contains(produto.getIdentificador()));
    }

    @Test @DisplayName("CT46: Gerar relatório JSON")
    void relatorioJson() {
        estoque.cadastrar(produto);
        estoque.adicionar(produto.getIdentificador(), 2, LocalDate.now().plusDays(5));
        String json = estoque.gerarRelatorioJSON();
        assertTrue(json.startsWith("["));
        assertTrue(json.contains("\"identificador\":\"" + produto.getIdentificador() + "\""));
    }

}