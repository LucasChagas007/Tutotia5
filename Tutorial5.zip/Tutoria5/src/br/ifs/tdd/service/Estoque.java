package br.ifs.tdd.service;

import java.util.HashMap;
import java.util.Map;

import br.ifs.tdd.exception.EstoqueInsuficienteException;
import br.ifs.tdd.exception.OperacaoInvalidaException;
import br.ifs.tdd.exception.ProdutoDuplicadoException;
import br.ifs.tdd.exception.ProdutoNaoEncontradoException;
import br.ifs.tdd.model.Lote;
import br.ifs.tdd.model.Produto;
import br.ifs.tdd.exception.*;

import java.time.LocalDate;
import java.util.*;

public class Estoque {
    private final Map<String, Produto> produtos = new HashMap<>();
    private final Map<String, List<Lote>> lotes = new HashMap<>();

    public void cadastrar(Produto produto) {
        if (produto == null)
            throw new ValidacaoException("Produto inválido");
        String id = produto.getIdentificador();
        if (produtos.containsKey(id))
            throw new ProdutoDuplicadoException(id);
        produtos.put(id, produto);
        lotes.put(id, new ArrayList<>());
    }

    public void remover(String identificador) {
        if (identificador == null || identificador.isBlank())
            throw new ValidacaoException("Identificador de produto inválido");
        if (!produtos.containsKey(identificador))
            throw new ProdutoNaoEncontradoException(identificador);
        if (!lotes.get(identificador).isEmpty())
            throw new OperacaoInvalidaException("Remova os lotes associados primeiro");
        produtos.remove(identificador);
        lotes.remove(identificador);
    }

    public Produto buscar(String identificador) {
        if (identificador == null || identificador.isBlank())
            throw new ValidacaoException("Identificador de produto inválido");
        if (!produtos.containsKey(identificador))
            throw new ProdutoNaoEncontradoException(identificador);
        return produtos.get(identificador);
    }

    public void atualizar(Produto produto) {
        if (produto == null)
            throw new ValidacaoException("Produto inválido");
        String id = produto.getIdentificador();
        if (!produtos.containsKey(id))
            throw new ProdutoNaoEncontradoException(id);
        produtos.put(id, produto);
    }

    public void adicionar(String identificador, int quantidade, LocalDate validade) {
        if (identificador == null || identificador.isBlank())
            throw new ValidacaoException("Identificador de produto inválido");
        if (!produtos.containsKey(identificador))
            throw new ProdutoNaoEncontradoException(identificador);
        if (quantidade <= 0)
            throw new ValidacaoException("Quantidade inválida");
        if (validade == null)
            throw new ValidacaoException("Data de validade inválida");
        if (validade.isBefore(LocalDate.now()))
            throw new ValidacaoException("Data de validade vencida");
        lotes.get(identificador).add(new Lote(produtos.get(identificador), quantidade, validade));
    }

    public void retirar(String identificador, int quantidade) {
        if (identificador == null || identificador.isBlank())
            throw new ValidacaoException("Identificador de produto inválido");
        if (!produtos.containsKey(identificador))
            throw new ProdutoNaoEncontradoException(identificador);
        if (quantidade <= 0)
            throw new ValidacaoException("Quantidade inválida");
        List<Lote> lista = lotes.get(identificador);
        int disponivel = lista.stream().mapToInt(Lote::getQuantidade).sum();
        if (quantidade > disponivel)
            throw new EstoqueInsuficienteException(identificador);
        lista.sort(Comparator.comparing(Lote::getDataValidade));
        int restante = quantidade;
        Iterator<Lote> it = lista.iterator();
        while (it.hasNext() && restante > 0) {
            Lote lote = it.next();
            if (lote.getQuantidade() <= restante) {
                restante -= lote.getQuantidade();
                it.remove();
            } else {
                int novaQt = lote.getQuantidade() - restante;
                it.remove();
                lista.add(new Lote(lote.getProduto(), novaQt, lote.getDataValidade()));
                restante = 0;
            }
        }
    }

    public int obterQuantidade(String identificador) {
        if (identificador == null || identificador.isBlank())
            throw new ValidacaoException("Identificador de produto inválido");
        if (!produtos.containsKey(identificador))
            throw new ProdutoNaoEncontradoException(identificador);
        return lotes.get(identificador).stream().mapToInt(Lote::getQuantidade).sum();
    }

    public int obterQuantidade() {
        return lotes.values().stream()
            .flatMap(Collection::stream)
            .mapToInt(Lote::getQuantidade)
            .sum();
    }

    public String gerarRelatorioTexto() {
        StringBuilder sb = new StringBuilder();
        produtos.keySet().forEach(id -> sb.append(id)
            .append(" - ")
            .append(obterQuantidade(id)).append(" unidades\n"));
        return sb.toString();
    }

    public String gerarRelatorioCSV() {
        StringBuilder sb = new StringBuilder("identificador,quantidade\n");
        produtos.keySet().forEach(id -> sb.append(id)
            .append(',').append(obterQuantidade(id)).append("\n"));
        return sb.toString();
    }

    public String gerarRelatorioJSON() {
        StringBuilder sb = new StringBuilder("[");
        produtos.keySet().forEach(id -> sb.append("{\"identificador\":\"")
            .append(id).append("\",\"quantidade\":")
            .append(obterQuantidade(id)).append("},"));
        if (sb.charAt(sb.length()-1)==',') sb.deleteCharAt(sb.length()-1);
        sb.append("]");
        return sb.toString();
    }
}